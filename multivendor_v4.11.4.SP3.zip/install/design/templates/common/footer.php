<?php if (!defined('INSTALLER_INITED')) { die('Access denied'); } ?>
</div>
</body>
</html>
